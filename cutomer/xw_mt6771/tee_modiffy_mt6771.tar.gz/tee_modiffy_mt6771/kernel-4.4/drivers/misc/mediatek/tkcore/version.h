#ifndef TKCORE_VERSION_H
#define TKCORE_VERSION_H

static const char tkcore_nsdrv_version[] = "3.2p3" "\n";

#endif
